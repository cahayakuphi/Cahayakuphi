# Cahaya Kuphi — Production release gate

## Owner-provided configuration recorded
- WhatsApp admin: `6282269696845` (international format, no `+`)
- Flat delivery fee: Rp5.000
- Address: Sumber Batu, Meureubo, Aceh Barat
- Operating hours: Monday–Sunday, 09:00–12:00 WIB
- Deployment target: Vercel subdomain first
- Supabase project exists; credentials have not been supplied to this source package

## Safe defaults
- `store_settings.accepting_orders` remains `false`.
- Do not place Supabase service-role keys in client-side variables or commit them.
- Do not claim an order was sent merely because WhatsApp opened.
- Do not mark transfer/QRIS as paid without admin verification.

## Blocking items before a production release
1. Fix checkout server pricing: calculate selected variant/extras from database option IDs; reject client-supplied price deltas.
2. Read the store settings server-side and apply Rp5.000 only to delivery; persist the correct final total.
3. Make order + order items atomic using a database RPC/transaction (current API inserts them separately).
4. Implement admin authorization on server routes and an explicit single-admin allowlist/role. Client-side session checks alone are insufficient.
5. Implement admin CRUD for menu, photos, stock, orders, payment verification, hours, and store settings.
6. Implement atomic stock decrement on confirmation and exactly-once restoration on cancellation, with stock movement audit.
7. Implement server-enforced expiration and safe cancellation/confirmation transitions.
8. Add rate limiting, request size limits, input validation, and privacy-safe tracking.
9. Add safe Supabase RLS policies and test public reads vs admin-only writes.
10. Add automated tests for checkout pricing, invalid inputs, concurrent stock confirmation, cancellation idempotency, tracking token, and authorization.
11. Run `npm ci`, `npm run build`, and end-to-end tests against a staging Supabase project.
12. Deploy to a Vercel preview URL; test with test data; verify logs and rollback path.
13. Only after owner acceptance, explicitly set `accepting_orders = true` and test one real low-risk order.

## Release decision
**BLOCKED — not production-ready.** The current app still uses a sample in-code catalog, and the admin dashboard is a placeholder. This checklist must not be treated as passed until evidence from build and end-to-end tests exists.
